﻿# Вивантаження всіх даних з бази АРМО (MS SQL) у CSV-файли.
# Тільки читання: скрипт виконує лише SELECT, нічого в базі не змінює.
# Налаштування підключення бере з C:\fw_net_clin\conf\config.xml.

param(
    [string]$ConfigPath = 'C:\fw_net_clin\conf\config.xml',
    [string]$OutRoot = [Environment]::GetFolderPath('Desktop')
)

$ErrorActionPreference = 'Stop'
$filesIncomplete = $false; $filesSrc = 0; $filesCopied = 0
$out =Join-Path $OutRoot ('ARMO_export_' + (Get-Date -Format 'yyyy-MM-dd_HH-mm'))
New-Item -ItemType Directory -Force -Path $out | Out-Null
$logFile = Join-Path $out '_log.txt'
function Log($msg) {
    $line = '[' + (Get-Date -Format 'HH:mm:ss') + '] ' + $msg
    Write-Host $line
    Add-Content -Path $logFile -Value $line -Encoding UTF8
}

# --- 1. Читаємо config.xml ---
if (-not (Test-Path $ConfigPath)) {
    Log ("На цьому комп'ютері не знайдено АРМО (немає файла " + $ConfigPath + ").")
    Log "Запустіть інструмент на комп'ютері, де встановлена й працює АРМО."
    Remove-Item -Path $out -Recurse -Force -ErrorAction SilentlyContinue
    exit 1
}
$xml = New-Object System.Xml.XmlDocument
$xml.Load($ConfigPath)
$raw = $xml.SelectSingleNode('/conf/datasource/primary').InnerText
$kv = @{}
foreach ($part in ($raw -split ';')) {
    $p = $part.Trim()
    if ($p -match '^\s*([^=]+?)\s*=\s*(.*)$') { $kv[$Matches[1].ToLower()] = $Matches[2].Trim() }
}
$b = New-Object System.Data.SqlClient.SqlConnectionStringBuilder
$b['Data Source']     = $kv['data source']
$b['Initial Catalog'] = $kv['initial catalog']
if ($kv['integrated security']) { $b['Integrated Security'] = $true }
else { $b['User ID'] = $kv['user id']; $b['Password'] = $kv['password'] }
$b['Connect Timeout'] = 15
$b['Application Name'] = 'ARMO export (read-only)'
Log ("Сервер: " + $b['Data Source'] + "  База: " + $b['Initial Catalog'])
Log ("Папка вивантаження: " + $out)

$conn = New-Object System.Data.SqlClient.SqlConnection $b.ConnectionString
try { $conn.Open() } catch { Log ("ПОМИЛКА підключення: " + $_.Exception.Message); exit 1 }
Log 'Підключено.'

function Get-Table($sql) {
    $cmd = $conn.CreateCommand(); $cmd.CommandText = $sql; $cmd.CommandTimeout = 0
    $dt = New-Object System.Data.DataTable
    $dt.Load($cmd.ExecuteReader()); return ,$dt
}

function Esc($v) {
    if ($null -eq $v -or $v -is [DBNull]) { return '' }
    if ($v -is [byte[]]) { return [Convert]::ToBase64String($v) }
    if ($v -is [DateTime]) { return $v.ToString('yyyy-MM-dd HH:mm:ss') }
    if ($v -is [decimal] -or $v -is [double] -or $v -is [single]) { $s = $v.ToString([Globalization.CultureInfo]::InvariantCulture) }
    else { $s = [string]$v }
    if ($s -match '[;"\r\n]') { return '"' + $s.Replace('"', '""') + '"' }
    return $s
}

function Export-Query($sql, $file) {
    $cmd = $conn.CreateCommand(); $cmd.CommandText = $sql; $cmd.CommandTimeout = 0
    $r = $cmd.ExecuteReader()
    $w = New-Object System.IO.StreamWriter($file, $false, (New-Object System.Text.UTF8Encoding($true)))
    $n = 0
    try {
        $names = for ($i = 0; $i -lt $r.FieldCount; $i++) { Esc $r.GetName($i) }
        $w.WriteLine(($names -join ';'))
        $vals = New-Object object[] $r.FieldCount
        while ($r.Read()) {
            [void]$r.GetValues($vals)
            $w.WriteLine((($vals | ForEach-Object { Esc $_ }) -join ';'))
            $n++
        }
    } finally { $w.Close(); $r.Close() }
    return $n
}

# --- 2. Структура бази (список таблиць і колонок) ---
$colsSql = @"
SELECT c.TABLE_SCHEMA, c.TABLE_NAME, c.ORDINAL_POSITION, c.COLUMN_NAME, c.DATA_TYPE,
       c.CHARACTER_MAXIMUM_LENGTH, c.IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS c
JOIN INFORMATION_SCHEMA.TABLES t ON t.TABLE_SCHEMA = c.TABLE_SCHEMA AND t.TABLE_NAME = c.TABLE_NAME
WHERE t.TABLE_TYPE = 'BASE TABLE'
ORDER BY c.TABLE_SCHEMA, c.TABLE_NAME, c.ORDINAL_POSITION
"@
[void](Export-Query $colsSql (Join-Path $out '_columns.csv'))

$fkSql = @"
SELECT fk.name AS FK, OBJECT_SCHEMA_NAME(fk.parent_object_id) AS FromSchema, OBJECT_NAME(fk.parent_object_id) AS FromTable,
       COL_NAME(fc.parent_object_id, fc.parent_column_id) AS FromColumn,
       OBJECT_SCHEMA_NAME(fk.referenced_object_id) AS ToSchema, OBJECT_NAME(fk.referenced_object_id) AS ToTable,
       COL_NAME(fc.referenced_object_id, fc.referenced_column_id) AS ToColumn
FROM sys.foreign_keys fk JOIN sys.foreign_key_columns fc ON fc.constraint_object_id = fk.object_id
"@
try { [void](Export-Query $fkSql (Join-Path $out '_relations.csv')) } catch { Log ("Зв'язки не вивантажено: " + $_.Exception.Message) }

# --- 3. Усі таблиці ---
$tables = Get-Table "SELECT TABLE_SCHEMA, TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE' ORDER BY TABLE_SCHEMA, TABLE_NAME"
Log ("Таблиць: " + $tables.Rows.Count)
$summary = New-Object System.Collections.Generic.List[string]
$summary.Add('table;rows;status')
$dataDir = Join-Path $out 'tables'
New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
# Колонки з паролями не вивантажуються взагалі (T27.12): для перенесення вони не потрібні.
$secretCols = Get-Table "SELECT c.TABLE_SCHEMA, c.TABLE_NAME, c.COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS c WHERE LOWER(c.COLUMN_NAME) LIKE '%password%' OR LOWER(c.COLUMN_NAME) LIKE '%passwd%'"
$secret = @{}
foreach ($r in $secretCols.Rows) {
    $k = $r.TABLE_SCHEMA + '.' + $r.TABLE_NAME
    if (-not $secret.ContainsKey($k)) { $secret[$k] = @() }
    $secret[$k] += [string]$r.COLUMN_NAME
}
$tablesOk = 0; $tablesErr = 0
$i = 0
foreach ($t in $tables.Rows) {
    $i++
    $full = $t.TABLE_SCHEMA + '.' + $t.TABLE_NAME
    $safe = ($full -replace '[\\/:*?"<>|]', '_')
    $file = Join-Path $dataDir ($safe + '.csv')
    $from = ' FROM [' + $t.TABLE_SCHEMA.Replace(']', ']]') + '].[' + $t.TABLE_NAME.Replace(']', ']]') + '] WITH (NOLOCK)'
    $q = 'SELECT *' + $from
    try {
        if ($secret.ContainsKey($full)) {
            $all = Get-Table ("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '" + $t.TABLE_SCHEMA.Replace("'", "''") + "' AND TABLE_NAME = '" + $t.TABLE_NAME.Replace("'", "''") + "' ORDER BY ORDINAL_POSITION")
            $keep = @($all.Rows | ForEach-Object { [string]$_.COLUMN_NAME } | Where-Object { $secret[$full] -notcontains $_ })
            if ($keep.Count -eq 0) { throw 'у таблиці лише колонки з паролями' }
            $q = 'SELECT ' + (($keep | ForEach-Object { '[' + $_.Replace(']', ']]') + ']' }) -join ', ') + $from
        }
        $n = Export-Query $q $file
        Log ("[$i/" + $tables.Rows.Count + "] $full : $n рядків")
        $summary.Add("$full;$n;ok")
        $tablesOk++
    } catch {
        Log ("[$i/" + $tables.Rows.Count + "] $full : ПОМИЛКА " + $_.Exception.Message)
        $summary.Add("$full;;error")
        $tablesErr++
    }
}
[System.IO.File]::WriteAllLines((Join-Path $out '_summary.csv'), $summary, (New-Object System.Text.UTF8Encoding($true)))
$conn.Close()

# --- 4. Налаштування АРМО з сервера (опис форм/полів допомагає зрозуміти таблиці) ---
$root = $xml.SelectSingleNode('/conf/root')
if ($root) {
    $share = $root.GetAttribute('dir')
    try {
        Copy-Item -Path (Join-Path $share 'conf') -Destination (Join-Path $out 'armo_conf') -Recurse -ErrorAction Stop
        Log 'Скопійовано папку conf з сервера.'
    } catch { Log ("Не вдалося скопіювати conf: " + $_.Exception.Message) }
    try {
        Get-ChildItem -Path $share -Recurse -Force -ErrorAction SilentlyContinue |
            Select-Object FullName, Length, LastWriteTime |
            Export-Csv -Path (Join-Path $out '_server_files.csv') -NoTypeInformation -Encoding UTF8 -Delimiter ';'
        Log 'Збережено список файлів на сервері (_server_files.csv).'
    } catch { Log ("Не вдалося отримати список файлів: " + $_.Exception.Message) }
    # висновки за візитами (HTML), на які посилається база
    # Копіюємо всю res\img: у базі є посилання не лише на visitHTML (напр. res\img\InspectExtLinks).
    # robocopy, а не Copy-Item (T27.12): мережева тека обривається — robocopy повторює спроби,
    # а повторний запуск докопійовує лише те, чого бракує.
    $img = Join-Path $share 'res\img'
    if (Test-Path $img) {
        Log 'Копіюю висновки за візитами (res\img). Це може зайняти 10-30 хвилин, вікно НЕ закривайте...'
        $dst = Join-Path $out 'img'
        & robocopy $img $dst /E /R:5 /W:10 /MT:8 /NP /NFL /NDL /NJH /NJS | Out-Null
        $rc = $LASTEXITCODE
        $filesSrc = @(Get-ChildItem -Path $img -Recurse -File -Force -ErrorAction SilentlyContinue).Count
        $filesCopied = @(Get-ChildItem -Path $dst -Recurse -File -Force -ErrorAction SilentlyContinue).Count
        Log ("Висновки: на сервері $filesSrc файлів, скопійовано $filesCopied (код robocopy $rc).")
        if ($rc -ge 8 -or $filesCopied -lt $filesSrc) { $filesIncomplete = $true; Log 'УВАГА: скопійовано не все. Запустіть вивантаження ще раз.' }
    } else { Log ("Теку з висновками не знайдено: " + $img) }
}

# --- 5. Готові Excel-файли: загальний, Львів, Луцьк ---
$py = Join-Path $PSScriptRoot 'python\python.exe'
$builder = Join-Path $PSScriptRoot 'build_tables.py'
if ((Test-Path $py) -and (Test-Path $builder)) {
    Log 'Збираю Excel-файли...'
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    $res = & $py -I -X utf8 $builder $out (Join-Path $out 'ARMO.xlsx') 2>&1
    foreach ($line in $res) { Log ([string]$line) }
    if ($LASTEXITCODE -eq 0) { Log 'Excel-файли готові: ARMO_загальний.xlsx, ARMO_Львів.xlsx, ARMO_Луцьк.xlsx' }
    else { Log 'ПОМИЛКА при збиранні Excel. Сирі дані в папці tables збережені.' }
}
# Без python поруч (версія інструмента для завантаження з Med Vision) Excel-файли не збираються:
# вони лише для перегляду очима, перенесенню в Med Vision не потрібні.

# --- 6. Маніфест і один архів (T27.12) ---
# Маніфест пишеться останнім: його наявність з complete=true означає, що вивантаження дійшло до кінця.
# Імпорт у Med Vision відмовляється від вивантаження без нього.
$complete = ($tablesErr -eq 0) -and (-not $filesIncomplete)
$manifest = '{' + "`r`n" +
    '  "tool": "armo-export",' + "`r`n" +
    '  "toolVersion": 2,' + "`r`n" +
    '  "finishedAt": "' + (Get-Date -Format 'yyyy-MM-ddTHH:mm:ss') + '",' + "`r`n" +
    '  "database": "' + ([string]$b['Initial Catalog']).Replace('\', '\\').Replace('"', '\"') + '",' + "`r`n" +
    '  "tables": ' + $tablesOk + ',' + "`r`n" +
    '  "tableErrors": ' + $tablesErr + ',' + "`r`n" +
    '  "filesOnServer": ' + [int]$filesSrc + ',' + "`r`n" +
    '  "filesCopied": ' + [int]$filesCopied + ',' + "`r`n" +
    '  "complete": ' + $(if ($complete) { 'true' } else { 'false' }) + "`r`n" + '}'
[System.IO.File]::WriteAllText((Join-Path $out '_manifest.json'), $manifest, (New-Object System.Text.UTF8Encoding($false)))

$zip = $out + '.zip'
try {
    Log 'Пакую в один архів...'
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    if (Test-Path $zip) { Remove-Item $zip -Force }
    [System.IO.Compression.ZipFile]::CreateFromDirectory($out, $zip, [System.IO.Compression.CompressionLevel]::Optimal, $false)
    Log ("Архів: " + $zip + " (" + [math]::Round((Get-Item $zip).Length / 1MB, 1) + " МБ)")
} catch { Log ("Не вдалося запакувати: " + $_.Exception.Message + ". Передайте папку як є.") }

if ($complete) { Log 'ГОТОВО. Передайте файл архіву (.zip).' }
else { Log 'ЗАВЕРШЕНО З ПОМИЛКАМИ: вивантаження неповне. Запустіть ще раз; якщо повториться - надішліть файл _log.txt.' }
Log ("Результат: " + $out)
try { Invoke-Item (Split-Path $out -Parent) } catch {}
