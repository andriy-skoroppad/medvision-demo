@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0export_armo.ps1"
pause
